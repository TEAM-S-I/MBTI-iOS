//
//  Secret.swift
//  mbti
//
//  Created by dgsw8th71 on 12/26/23.
//

import Foundation

class Secret {
    static let baseUrl = "https://mbti1234.azurewebsites.net"
}
