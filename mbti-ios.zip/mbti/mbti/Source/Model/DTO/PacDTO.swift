//
//  PacDTO.swift
//  mbti
//
//  Created by dgsw8th71 on 1/1/24.
//

import Foundation

struct PacDTO: Hashable {
    let team: PacTeamDTO
}
