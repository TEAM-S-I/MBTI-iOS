//
//  TeamResposne.swift
//  mbti
//
//  Created by dgsw8th71 on 12/26/23.
//

import Foundation

struct TeamResponse: Decodable {
    let team: [TeamDescriptionResponse]
}
